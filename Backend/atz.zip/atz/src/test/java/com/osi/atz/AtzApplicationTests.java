package com.osi.atz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtzApplicationTests {

	@Test
	void contextLoads() {
	}

}
