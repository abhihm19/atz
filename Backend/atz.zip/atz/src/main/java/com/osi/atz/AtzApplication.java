package com.osi.atz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtzApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtzApplication.class, args);
	}

}
